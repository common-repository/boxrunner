=== BoxRunner ===
Contributors: https://profiles.wordpress.org/crowderia
Donate link: http://crowderia.com
Tags: comments, spam
Requires at least: 1.0.0
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

BoxRunner plugin helps you to integrate your web-shop with BoxRunner. BoxRunner is a warehouse management system with web-shops.

== Description ==

BoxRunner is a plugin to integrate your woocommerce web shop with BoxRunner warehouse management system (http://boxrunner.net).
Through this plugin you can sync your products to the BoxRunner system and manage your warehouse. It manages products, categorys, picking, packing and shipping your products .Also users can make sales order in the webshop, we process the order in BoxRunner. Furthermore if user adds a new product in warehouse side, it automatically sync to the web shop after the configuration is successfully done. This plugin is really helpful for the user to manage their web shop and warehouse.


== Installation ==

1.Select 'Add new' in the 'Plugins' menu
2.Find and install the latest Boxrunner plugin for WooCommerce.
3.Activate the plugin.
4.Setup the module under  'Settings' / 'BoxRunner'

Manual Installation

1.Upload the folder boxrunner manually to the /wp-content/plugins/ directory through FTP.
2.Activate the plugin through the 'Plugins' menu in WordPress
3.Setup the module under 'Setting' / 'BoxRunner' 

== Frequently Asked Questions ==

= How to connect the BoxRunner? =

Go to wordpress settings and check whether given fields are filled correctly and save it. If it is not connected, please contact Boxrunner support (http://support.boxrunner.net).

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png). Note that the screenshot is taken from
/settings of the BoxRunner to connect with BoxChain (1.0). Screenshots in the /assets

== Changelog ==


== Arbitrary section ==

1.Sync product and orders when creating to the BoxRunner.
2.Sync all product at once.
